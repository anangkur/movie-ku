package com.anangkur.madesubmission1.data.model

data class Dates(
    val maximum: String,
    val minimum: String
)