package com.anangkur.madesubmission1.feature.main

interface MainActionListener {
    fun onClickSearch()
}