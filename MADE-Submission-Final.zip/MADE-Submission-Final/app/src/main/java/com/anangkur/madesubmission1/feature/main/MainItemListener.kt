package com.anangkur.madesubmission1.feature.main

import com.anangkur.madesubmission1.data.model.Result

interface MainItemListener {
    fun onClickItem(data: Result)
}